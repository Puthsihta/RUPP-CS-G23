package com.company;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
	// write your code here
        int row;
        Scanner in = new Scanner(System.in);
        System.out.print("Enter Row : ");
        row = in.nextInt();

        for (int i = 1; i<=row; i++)
        {
            for (int j = 1; j <=i;  j++)
            {
                System.out.print(j);
            }
            System.out.println();
        }
        int row1;
        Scanner in1 = new Scanner(System.in);
        System.out.print("Enter Row : ");
        row1 = in1.nextInt();

        for (int i = 1; i<=row1; i++)
        {
            for (int j = 1; j <=i;  j++)
            {
                System.out.print(i);
            }
            System.out.println();
        }
        int row2, k=1;
        Scanner in2 = new Scanner(System.in);
        System.out.print("Enter Row : ");
        row2 = in2.nextInt();

        for (int i = 1; i<=row2; i++)
        {
            for (int j = 1; j <=i;  j++)
            {
                System.out.print(k++ +" ");
            }
            System.out.println();
        }
    }
}
