package com.company;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
	// write your code here
        Scanner in = new Scanner(System.in);
        double a, b, c, data, root1, root2;
        System.out.print("Enter A : ");
        a = in.nextDouble();
        System.out.print("Enter B : ");
        b = in.nextDouble();
        System.out.print("Enter C : ");
        c = in.nextDouble();

        if (a == 0)
        {
            root1=root2=(-c)/b;
            System.out.println("Root = " + root1);
        }else
        {
            data = ((b*b) - 4*(a*c));
            if (data < 0)
            {
                System.out.println("No Root");
            }else if (data == 0)
            {
                root1=root2=(-b)/(2*a);
                System.out.println("Root 1 = Root 2 = " + root1);
            }else
            {
                root1 = (-b + Math.sqrt(data))/(2*a);
                root2 = (-b - Math.sqrt(data))/(2*a);
                System.out.println("Root 1 = " + root1);
                System.out.println("Root 2 = " + root2);
            }
        }


    }
}
