package com.company;

import java.util.Random;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
	// write your code here
        Scanner in = new Scanner(System.in);
        Random random = new Random();

        int guess, answer;
        final  int maxNum = 6;

        answer = random.nextInt(maxNum) + 1;

        int count = 0;
        do {
            System.out.print("Enter Number (1 - 6) = ");
            guess = in.nextInt();

            if (guess == answer)
            {
                System.out.println("===========Congratulations============");
                return;
            }else if (guess >= answer)
            {
                System.out.println( guess + " is bigger than ");
            }else if (guess <= answer)
            {
                System.out.println( guess + " is smaller than ");
            }
            count++;
        }while (count != 5);
        System.out.println("=============You Lost============");
    }
}
